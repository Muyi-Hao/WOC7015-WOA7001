# Team Meeting Discussion

Back to [README.md](../README.md)

## Meeting 27 December 2022

1. Discussion on the optimisation formula for the material transfer process
   - Wai Key is tasked to finish up the report
2. Graphical User Interface update
3. Arduino code update
