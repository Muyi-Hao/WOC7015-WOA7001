# Team Meeting Discussion

Back to [README.md](../README.md)

## Meeting on Saturday, 24 December 2022

1. 27 December 2022, go on campus to work on the project
2. Arduino code / C++ code for robotic arm work it out - Hafiidz and Chong
3. GUI need to set it up and communicate with Arduino - Gary, Yulin, Sarah
   - [Youtube link](https://www.youtube.com/watch?v=gQYsUjT-IBo)
   - NodeJS implementation
4. Optimization will be tasked to Wai Key - Chong need to call him.
5. SRS need to fix up and add in more information
6. SE teams do what?
   - Liaise with Ahmad - Chong
   - Liaise with Nasib - Gary
   - Liaise with China people - Yulin
   - SRS document - need SE team to help edit or correct the format.
7. Hard deadline - 6 January 2023
   - soft deadline - 30 December 2022
8. The github that will be used for the robotic motion - Gary & Hafiidz
   - [Repo: Inverse Kinematic Library for Arduino](https://github.com/cgxeiji/CGx-InverseK)