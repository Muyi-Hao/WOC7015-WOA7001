# Team Meeting Discussion

Back to [README.md](../README.md)

We'll schedule another session on Monday (28 Nov 2022) to finalize the deliverables

1. ICT-INOV platform
   - Team building and Empathize
     - Team Canvas Basic - please edit it and supplement your information on the diagram.
       - will be submitted to the website by 27 November 2022
     - End user persona - please supplement your information in the powerpoint shared with your literature review.
       - will be submitted to the website by 28 November 2022
   - Define - to be finalized on the 28 November 2022
     - Defining the problem
     - List of resources related to problem
       - literature review for the problems defined (online articles, news etc.)
2. Literature review on the problem defined.
   - Heavy workload and not ergonomic to human.
   - Accuracy and reliability of the process is low.
   - Packaging efficiency is low.
   - Not hygienic due to human involvement.
