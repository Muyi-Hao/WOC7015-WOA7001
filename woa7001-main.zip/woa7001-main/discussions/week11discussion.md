# Team Meeting Discussion

Back to [README.md](../README.md)

1. The arduino code for robotic arm is implemented successful with libraries:
    - InverseK 
    - Servo
    - ArduinoJson
2. GUI development is successful with core functionality implemented
    - X,Y,Z input
    - Camera - OpenCV coordination with computer vision.