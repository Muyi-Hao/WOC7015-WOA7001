| No | Name                       | Matric     | Program |   |
|----|----------------------------|------------|---------|---|
| 1  | Chong Chia Hsing           | S2159070/1 | MCS AC  |   |
| 2  | Lee Wai Key                | 17194567/2 | MCS AC  |   |
| 3  | Mohd Hafiidz Hassan        | S2147238   | MCS AC  |   |
| 4  | Gary Yee Siew Wah          | S2190954   | MCS AC  |   |
| 5  | Normaisarah binti Ab Majid | 17150714   | MCS AC  |   |
| 6  | Yulin Lei                  | s2152115   | MCS AC  |   |
| 7  | Ahmad Allehyany            | S2162429   | MSE     |   |
| 8  | Nasib Ullah                | S2019652   | MSE     |   |
| 9  | Zhenfei Cao                | S2142499   | MSE     |   |
| 10 | WangShifeng                | S2104917   | MSE     |   |
| 11 | Hao Yang                   | S2028894   | MSE     |   |