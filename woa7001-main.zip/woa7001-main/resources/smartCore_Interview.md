# Interview with SmartCore Digital Sdn Bhd

- Date: 21 December 2022
- Time: 1100
- Agenda

  - paddy and rice milling industry
  - Automation for the industry
  - Robotic arm automation for the industry

- Robotic arm
  - not a vendor but deployment
  - not much use in oil and gas
  - amyaml oil and gas robotic vehicle
- company
  - premiere digital solution
  - robotic arm
    - Malaysia only for lucrative industry
  - sponsorship by government
  - conversation with UM
    - Paddy plantation
      - increase yields
      - decrease the cost
    - rice milling
      - a lot of closure in malaysia
      - don't bother
      - mechanical because it's not digital
        - hard to penetrate
      - initial material transfer from paddy into factory
      - government incentives
  - Optimization
    - Process
      - petronas
      - Cost
      - Productivity
    - algorithm
      - time complexity
      - computation
