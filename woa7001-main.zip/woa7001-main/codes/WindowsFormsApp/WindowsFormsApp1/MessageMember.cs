﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class MessageMember
    {
        public int code { get; set; }
        public string msg { get; set; }
    }
}
